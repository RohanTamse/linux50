#!/bin/bash
echo "Hello, World!"
echo "This is my first shell script"
echo "Today's date is $(date)"
echo "Welcome to the world of shell scripting"
echo "Let's start learning!"
