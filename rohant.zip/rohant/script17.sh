#!/bin/bash
current_date=$(date +%d)
month=$(date +%m)
year=$(date +%Y)

echo "Today is $(date +%A), $month/$current_date/$year"
