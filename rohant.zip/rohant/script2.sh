#!/bin/bash
echo "Enter two numbers:"
read num1 num2
sum=$((num1 + num2))
product=$((num1 * num2))
echo "Sum: $sum, Product: $product"
